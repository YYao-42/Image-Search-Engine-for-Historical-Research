class EmptyTensorError(Exception):
    pass


class NoGradientError(Exception):
    pass
